# AI Study Buddy

Streamlit camera app that gives funny voice reminders (book / sleep / away)
in Roman English, Urdu or English.

## Files
- app.py            : the whole app
- requirements.txt  : Python packages
- packages.txt      : system packages for Streamlit Cloud (libgl1)

## Run locally
    py -3.11 -m venv venv
    venv\Scripts\activate
    pip install -r requirements.txt
    streamlit run app.py

## Deploy
Streamlit Community Cloud -> Python 3.11 -> main file app.py
After changing requirements.txt or packages.txt: Reboot the app.

## Where to change things (app.py)
- MESSAGES            : funny lines per language
- StudyBuddyProcessor.COOLDOWN       : seconds between alerts
- StudyBuddyProcessor.EAR_THRESHOLD  : eye-closed sensitivity (higher = more alerts)
- StudyBuddyProcessor.SLEEP_SECONDS  : how long eyes stay closed
- StudyBuddyProcessor.AWAY_SECONDS   : how long no face before "away"
